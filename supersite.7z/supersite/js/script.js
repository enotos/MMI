function move() {
	$(".who-btn").click(function() {
    $('html, body').animate({
        scrollTop: $(".project").offset().top
    }, 1000);
});
	$('.launch-now').click(function() {
		$('html,body').animate({
			scrollTop:$('.projects').offset().top	
		},1000)
	});

};
function schetchik() {
		$('.count').each(function() {
		$(this).prop('Counter',0).animate({
			Counter:$(this).text()
		},{
			duration:4000,
			easing:'swing',
			step:function(now) {
				$(this).text(Math.ceil(now));
			}		
		});
	});
};
schetchik();
move();
